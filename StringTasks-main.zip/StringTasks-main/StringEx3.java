package com.practice.stringAssignment;

public class StringEx3 {

	public static void main(String[] args) {
		String str = "welcome to carrertuner";
		String str1="come";
		if(str.contains(str1))
			System.out.println(" The string '"+str+"' contains '"+str1+"' sequence");
	}

}
