package com.practice.stringAssignment;

public class StringEx1 {

	public static void main(String[] args) {
		String str= "Welcome to Java World";
		System.out.println("Character at index 5: "+str.charAt(5));
	}

}
