package com.practice.stringAssignment;

public class StringEx4 {

	public static void main(String[] args) {
		String str = "String Tasks";
		String str1 = "Tasks";
		if(str.endsWith(str1)) {
			System.out.println("Given String ends with the content of another string");
		}

	}

}
