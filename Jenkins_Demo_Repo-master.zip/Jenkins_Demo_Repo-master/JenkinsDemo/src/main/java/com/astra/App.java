package com.astra;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! Jenkins" );
        System.out.println( "Hello World! Jenkins print" );
        System.out.println( "welcome to india" );

    }
}
