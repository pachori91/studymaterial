package com.ktg.oops;

public class Employee {
	private int eid;
	private String ename;
	private float esal;
	private String eadd;
	private String edesg;

	// setters and getters

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;

	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public float getEsal() {
		return esal;
	}

	public void setEsal(float esal) {
		this.esal = esal;
	}

	public String getEadd() {
		return eadd;
	}

	public void setEadd(String eadd) {
		this.eadd = eadd;
	}

	public String getEdesg() {
		return edesg;
	}

	public void setEdesg(String edesg) {
		this.edesg = edesg;
	}

}
