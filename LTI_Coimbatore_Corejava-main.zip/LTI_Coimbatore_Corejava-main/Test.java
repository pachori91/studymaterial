class Test
{

public static void main(String args[])
{
	int firstNum=Integer.parseInt(args[0]);//"123" parseInt

	int secondNum=Integer.parseInt(args[1]);
	
	int result=firstNum+secondNum;
	System.out.println("Addition of two numbers :"+result);
	
}

}