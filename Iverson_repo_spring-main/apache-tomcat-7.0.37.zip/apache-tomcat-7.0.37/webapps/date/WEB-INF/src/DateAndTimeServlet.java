import java.util.*;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class DateAndTimeServlet extends HttpServlet{
public void service(HttpServletRequest request, HttpServletResponse response)throws IOException{
Date d = new Date();
PrintWriter out = response.getWriter();
out.println(d);
System.out.println(d);
}
}

