

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Project
 */
public class Task1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";  
	static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    static final String USER = "karan";
	static final String PASS = "ibm";  
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     String id=request.getParameter("id");
	
     String task=request.getParameter("status");
     
     
      Connection conn = null;
	 PreparedStatement pstmt = null;

	 try{
	     
	      Class.forName(JDBC_DRIVER);

	     System.out.println("Connecting to a selected database...");
	      conn = DriverManager.getConnection(DB_URL, USER, PASS);
	      System.out.println("Connected database successfully...");
	      String sql = "update task set status=? where id=?";
	     
	      pstmt=conn.prepareStatement(sql);
	      pstmt.setString(1, task);
	      pstmt.setString(2, id);
		      
	      
          int i=pstmt.executeUpdate();
          if(i>0){
        	  
        	  HttpSession hs=request.getSession();
        	  hs.setAttribute("task", "Task Assigned");
        	  request.getRequestDispatcher("task.jsp").forward(request, response);
        	  
          }else{
        	  HttpSession hs=request.getSession();
        	  hs.setAttribute("task", "Task Assignment Failed");
        	  request.getRequestDispatcher("task.jsp").forward(request, response);
        	  
        	  
          }
		}catch(SQLException se){
	      //Handle errors for JDBC
	      se.printStackTrace();
	   }catch(Exception e){
	      //Handle errors for Class.forName
	      e.printStackTrace();
	   }finally{
	      //finally block used to close resources
	      try{
	         if(conn!=null)
	            conn.close();
	      }catch(SQLException se){
	         se.printStackTrace();
	      }//end finally try
	   }//end try
 System.out.println("Goodbye!");
	}//end main
}
