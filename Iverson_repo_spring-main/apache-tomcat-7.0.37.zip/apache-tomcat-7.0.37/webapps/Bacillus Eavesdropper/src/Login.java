

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";  
	static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    static final String USER = "karan";
	static final String PASS = "ibm";

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Connection conn = null;
		PreparedStatement pstmt = null;
		String user=request.getParameter("uname");
		String password=request.getParameter("password");
		
		//pw.println(user + password);
		
		 String pass=null;
		 int id=0;
		  try{
		     
		      Class.forName(JDBC_DRIVER);

		     System.out.println("Connecting to a selected database...");
		      conn = DriverManager.getConnection(DB_URL, USER, PASS);
		      System.out.println("Connected database successfully...");
		      String sql = " select id,password from login where username= ? ";
		     
		      pstmt=conn.prepareStatement(sql);
		      
		      pstmt.setString(1, user);
		      
		      ResultSet rs=pstmt.executeQuery();
		      
		      //STEP 5: Extract data from result set
		 
		      while(rs.next()){
		         
		    	  id=rs.getInt("id");
		    	  pass = rs.getString("password");
		          
		        }
		     
		     
		      if(pass.equals(password) && id==1){
		    	      out.println("<html>"); 
		    	      out.println("<head>");
		    	      out.println("<style>");
		    	      out.println("body{ background: url('reg.jpg');background-position: fixed;background-repeat: no-repeat; background-size: cover;width: 70%;height: 500px;}");
                      out.println("h5{color: white; font-family: Comic Sans MS ; font-size: 20px; }");
                      out.println("button{background-color: rgba(62, 62, 40,0.8);border: none; color: white;padding: 15px 32px; text-align: center;  text-decoration: none; display: inline-block;font-size: 16px;}");
		    	      out.println("</style>");
		    	      out.println("</head>");
		    	      out.println("<body>");
		    		  out.println("<center>");
		    		  out.println("<h5>Login Successfull</h5>");
		    		  out.println("<a href='admin.jsp?user="+user+"' target='_top'><button>Go to admin area:</button></a>");
		    		  out.println("<center>");
		    		  out.println("</body>");
		    		  out.println("</html>");
		      }
		      
		      else if(pass.equals(password) && id==2){
		    	  
		    	  out.println("<html>"); 
	    	      out.println("<head>");
	    	      out.println("<style>");
	    	      out.println("body{ background: url('reg.jpg');background-position: fixed;background-repeat: no-repeat; background-size: cover;width: 70%;height: 500px;}");
                  out.println("h5{color: white; font-family: Comic Sans MS ; font-size: 20px; }");
                  out.println("button{background-color: rgba(62, 62, 40,0.8);border: none; color: white;padding: 15px 32px; text-align: center;  text-decoration: none; display: inline-block;font-size: 16px;}");
	    	      out.println("</style>");
	    	      out.println("</head>");
	    	     
		    	  out.println("<body>");
	    		  out.println("<center>");
	    		  out.println("<h5>Login Successfull</h5>");
	    		  out.println("<a href='manager.jsp?user="+user+"' target='_top'><button>Go to Manager area:</button></a>");
	    		  out.println("<center>");
	    		  out.println("<body>");
	    		  out.println("</html>");
	      }
		      else if(pass.equals(password) && id==3){
		    	  
		    	  out.println("<html>"); 
	    	      out.println("<head>");
	    	      out.println("<style>");
	    	      out.println("body{ background: url('reg.jpg');background-position: fixed;background-repeat: no-repeat; background-size: cover;width: 70%;height: 500px;}");
                  out.println("h5{color: white; font-family: Comic Sans MS ; font-size: 20px; }");
                  out.println("button{background-color: rgba(62, 62, 40,0.8);border: none; color: white;padding: 15px 32px; text-align: center;  text-decoration: none; display: inline-block;font-size: 16px;}");
	    	      out.println("</style>");
	    	      out.println("</head>");
	    	      
		    	  out.println("<body>");
	    		  out.println("<center>");
	    		  out.println("<h5>Login Successfull</h5>");
	    		  out.println("<a href='developer.jsp?user="+user+"' target='_top'><button>Go to Developer area:</button></a>");
	    		  out.println("<center>");
	    		  out.println("<body>");
	    		  out.println("</html>");
	      }
		      else if(pass.equals(password) && id==4){
		    	  
		    	  out.println("<html>"); 
	    	      out.println("<head>");
	    	      out.println("<style>");
	    	      out.println("body{ background: url('reg.jpg');background-position: fixed;background-repeat: no-repeat; background-size: cover;width: 70%;height: 500px;}");
                  out.println("h5{color: white; font-family: Comic Sans MS ; font-size: 20px; }");
                  out.println("button{background-color: rgba(62, 62, 40,0.8);border: none; color: white;padding: 15px 32px; text-align: center;  text-decoration: none; display: inline-block;font-size: 16px;}");
	    	      out.println("</style>");
	    	      out.println("</head>");
	    	      
		    	  out.println("<body>");
	    		  out.println("<center>");
	    		  out.println("<h5>Login Successfull</h5>");
	    		  out.println("<a href='tester.jsp?user="+user+"' target='_top'><button>Go to Tester area:</button></a>");
	    		  out.println("<center>");
	    		  out.println("<body>");
	    		  out.println("</html>");
	      }
	      
		      else {
		    	  out.println("<html>"); 
	    	      out.println("<head>");
	    	      out.println("<style>");
	    	      out.println("body{ background: url('reg.jpg');background-position: fixed;background-repeat: no-repeat; background-size: cover;width: 70%;height: 500px;}");
                  out.println("h5{color: white; font-family: Comic Sans MS ; font-size: 20px; }");
                  out.println("button{background-color: rgba(62, 62, 40,0.6);border: none; color: white;padding: 15px 32px; text-align: center;  text-decoration: none; display: inline-block;font-size: 16px;}");
	    	      out.println("</style>");
	    	      out.println("</head>");
	    	     
		    	  out.println("<body>");
		    	  out.println("<center>");
	    		  out.println("<h5>Login Failed</h5>");
	    		  out.println("<a href='login.jsp?role=emp' target='content' ><button>Try again</button></a>");
	    		  out.println("<center>");
	    		  out.println("<body>");
	    		  out.println("</html>");
		      }
		           
		}catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
	   System.out.println("Goodbye!");
		}//end main
		//end JDBCExample
	
	}


