package com.rps.demo.exceptions;

public class EmployeeIdNotFound extends RuntimeException {
public EmployeeIdNotFound(String message) {
super(message);
}
}
