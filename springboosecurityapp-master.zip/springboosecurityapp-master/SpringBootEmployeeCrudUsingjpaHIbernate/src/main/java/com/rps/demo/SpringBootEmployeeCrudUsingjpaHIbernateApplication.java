package com.rps.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeCrudUsingjpaHIbernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeCrudUsingjpaHIbernateApplication.class, args);
	}

}
